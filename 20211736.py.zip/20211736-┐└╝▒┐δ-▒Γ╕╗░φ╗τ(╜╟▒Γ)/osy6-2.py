c = ['sunday','monday','tuesday','wednesday','thursday','friday','saturaday']

c_upper = []

c_capitalize = [i.capitalize() for i in c]
print(c_capitalize)