hap = 0                                                     # 알파벳의 개수를 저장하는 변수

while(1):                                                   # 반복문을 통해 한 글자 알파벳만을 입력 받는다.
    s = input("개수를 알고 싶은 알파벳을 입력하세요. : ")

    if(len(s) == 1):                                        # 한 글자를 입력 받는다.
        if(ord(s) >= 65 and ord(s) <= 90):                  # 아스키 코드를 이용하여 대문자 A~Z 까지만 입력 받는다.
            break
        elif(ord(s) >= 97 and ord(s) <= 122):               # 아스키 코드를 이용하여 소문자 a~z 까지만 입력 받는다.
            break
        else:
            print("숫자말고 알파벳을 입력하세요.\n")
    else:
        print("알파벳 하나를  입력하세요.\n")



f = open("test.txt", 'r', encoding="UTF-8")                 # 읽을 파일을 불러온다

lines = f.readlines()                                       # 파일의 처음 부터 끝까지 읽는다.

str = ''.join(lines)                                        # 리스트에 저장된 파일의 내용을 문자열로 바꾼다.
print("\n[파일 내용]")
print(str)
list(str)                                                   # 문자열인 파일의 내용을 다시 한 글자씩 리스트로 바꾼다.

for i in str:
    if(i == s):                                             # 리스트에서 찾고자하는 알파벳이 있으면 변수의 값이 1씩 증가
        hap += 1

print("\n\n찾고자 하는 알파벳 :",s, "\n개수 :", hap)

f.close()