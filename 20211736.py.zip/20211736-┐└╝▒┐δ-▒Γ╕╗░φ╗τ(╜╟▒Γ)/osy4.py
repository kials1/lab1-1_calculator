a = int(input("시작 값 : "))
d = int(input("등차 : "))
n = int(input("정수 : "))

a = int(a)
d = int(d)
n = int(n)

x = list(range(a,n+1,d)); 

print(x)
print(len(x))

s = 0 
for i in range(0, len(x)):
    s = s + x[i]; 
print('sum of the numbers: %d' %(s))
