
def celsius(x):
        return 9*x/5+32
def celsius(y):
    return (y-32) * 5/9
a = str(input("변환 할 온도를 입력하시오 : "))


if a == 'c':
    x = float(input("섭씨 온도 입력 :"))
    print("화씨 온도 : ", celsius(x))

elif a == 'f':
    y = float(input("화씨 온도 입력 :"))
    print("섭씨 온도 : ", celsius(y))
else:
    print("종료")
