c = ['sunday','monday','tuesday','wednesday','thursday','friday','saturaday']



c_upper = []

search = 'sday'
for i, word in enumerate(c):
        c[i] = word.strip(search)
print(c_upper)

for i in c:
    c_upper.append(i.upper())
print(c_upper)

